const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const port = 3000;
const logFilePath = path.join(__dirname, 'example.log');

var len = logFilePath.length - 11 ;
app.use(express.static('../client'));


let clients = [];

const monitorLogFile = () => {
    fs.watchFile(logFilePath, (curr, prev) => {
        if (curr.mtime > prev.mtime) {
            // fs.readFile(logFilePath, 'utf8', (err, data) => {
            //     if (err) throw err;
            //     const newLines = data.split('\n').slice(-10).join('\n');
            //     broadcast(newLines);
            // });

            const buffer = Buffer.alloc(4096);
            fs.open(logFilePath, 'r', (err, fd) => {
              if (err) throw err;
              fs.stat(logFilePath, (err, stats) => {
                if (err) throw err;
                const fileSize = stats.size;
                const position = Math.max(0, fileSize - 11);
                fs.read(fd, buffer, 0, buffer.length, position, (err, bytesRead, buffer) => {
                  if (err) throw err;
                  const newLines = buffer.toString();
                  broadcast(newLines);
                  fs.close(fd, (err) => {
                    if (err) throw err;
                  });
                });
              });
            });


            


            
        }
    });
};

const broadcast = (data) => {
    clients.forEach(client => {
        client.emit('logUpdate', data);
    });
};

monitorLogFile();


io.on('connection', (socket) => {
    console.log('New client connected');
    clients.push(socket);
    
    fs.readFile(logFilePath, 'utf8', (err, data) => {
        if (err) {
            socket.emit('error', 'Error reading log file');
            return;
        }
        const last = data.split('\n').slice(-10).join('\n');
        socket.emit('logUpdate', last);
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected');
        clients = clients.filter(client => client !== socket);
    });
});

server.listen(port, () => {
    console.log(`Server is listening on http://localhost:${port}`);
});
